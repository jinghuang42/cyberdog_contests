# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/BLASReplacement.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/BLASReplacement.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/Bounds.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/Bounds.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/Constraints.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/Constraints.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/Flipper.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/Flipper.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/Indexlist.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/Indexlist.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/LAPACKReplacement.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/LAPACKReplacement.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/Matrices.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/Matrices.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/MessageHandling.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/MessageHandling.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/OQPinterface.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/OQPinterface.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/Options.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/Options.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/QProblem.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/QProblem.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/QProblemB.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/QProblemB.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/SQProblem.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/SQProblem.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/SQProblemSchur.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/SQProblemSchur.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/SolutionAnalysis.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/SolutionAnalysis.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/SparseSolver.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/SparseSolver.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/SubjectTo.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/SubjectTo.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/qpOASES/src/Utils.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/src/Utils.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "BUILD_CYBERDOG2=1"
  "ONBOARD_BUILD=1"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/usr/xcc/aarch64-openwrt-linux-gnu/aarch64-openwrt-linux-gnu/usr/include/eigen3"
  "../control/."
  "../control/include"
  "../control/include/control"
  "../control/third_party"
  "."
  "../common/third_party"
  "../common/third_party/ParamHandler"
  "../common/include"
  "../control/third_party/qpOASES/include"
  )

# Pairs of files generated by the same build rule.
set(CMAKE_MULTIPLE_OUTPUT_PAIRS
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/libs/libqpOASES.so" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/libs/libqpOASES.so.3.2"
  )


# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
