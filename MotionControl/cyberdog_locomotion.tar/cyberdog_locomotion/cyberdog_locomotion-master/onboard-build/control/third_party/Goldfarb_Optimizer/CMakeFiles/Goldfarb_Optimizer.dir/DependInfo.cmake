# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/Goldfarb_Optimizer/Array.cc" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/Goldfarb_Optimizer/CMakeFiles/Goldfarb_Optimizer.dir/Array.cc.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/third_party/Goldfarb_Optimizer/QuadProg++.cc" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/Goldfarb_Optimizer/CMakeFiles/Goldfarb_Optimizer.dir/QuadProg++.cc.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "BUILD_CYBERDOG2=1"
  "ONBOARD_BUILD=1"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/usr/xcc/aarch64-openwrt-linux-gnu/aarch64-openwrt-linux-gnu/usr/include/eigen3"
  "../control/."
  "../control/include"
  "../control/include/control"
  "../control/third_party"
  "."
  "../common/third_party"
  "../common/third_party/ParamHandler"
  "../common/include"
  "../control/third_party/qpOASES/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
