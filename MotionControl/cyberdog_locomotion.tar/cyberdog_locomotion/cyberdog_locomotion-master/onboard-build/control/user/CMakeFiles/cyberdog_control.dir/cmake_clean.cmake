file(REMOVE_RECURSE
  "CMakeFiles/cyberdog_control.dir/main.cpp.o"
  "CMakeFiles/cyberdog_control.dir/sub_main.cpp.o"
  "cyberdog_control.pdb"
  "cyberdog_control"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/cyberdog_control.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
