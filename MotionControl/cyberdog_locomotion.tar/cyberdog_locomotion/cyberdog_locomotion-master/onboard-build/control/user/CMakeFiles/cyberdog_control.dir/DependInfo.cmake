# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/user/main.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/user/CMakeFiles/cyberdog_control.dir/main.cpp.o"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/control/user/sub_main.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/user/CMakeFiles/cyberdog_control.dir/sub_main.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "BUILD_CYBERDOG2=1"
  "ONBOARD_BUILD=1"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/usr/xcc/aarch64-openwrt-linux-gnu/aarch64-openwrt-linux-gnu/usr/include/eigen3"
  "../control/."
  "../control/include"
  "../control/include/control"
  "../control/third_party"
  "."
  "../common/third_party"
  "../common/third_party/ParamHandler"
  "../common/include"
  "../control/user/."
  "../hardware/include"
  "../hardware/include/hardware"
  "../common/third_party/cpptoml/include"
  "../control/third_party/qpOASES/include"
  "/usr/xcc/aarch64-openwrt-linux-gnu/aarch64-openwrt-linux-gnu/usr/local/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/hardware/CMakeFiles/hardware.dir/DependInfo.cmake"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/CMakeFiles/control.dir/DependInfo.cmake"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/qpOASES/CMakeFiles/qpOASES.dir/DependInfo.cmake"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/control/third_party/Goldfarb_Optimizer/CMakeFiles/Goldfarb_Optimizer.dir/DependInfo.cmake"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/common/CMakeFiles/common.dir/DependInfo.cmake"
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/common/third_party/ParamHandler/CMakeFiles/param_handler.dir/DependInfo.cmake"
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
