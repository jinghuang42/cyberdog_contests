file(REMOVE_RECURSE
  "CMakeFiles/common.dir/src/command_interface/command_interface.cpp.o"
  "CMakeFiles/common.dir/src/control_parameters/control_parameter_interface.cpp.o"
  "CMakeFiles/common.dir/src/control_parameters/control_parameters.cpp.o"
  "CMakeFiles/common.dir/src/controllers/leg_controller.cpp.o"
  "CMakeFiles/common.dir/src/dynamics/floating_base_model.cpp.o"
  "CMakeFiles/common.dir/src/dynamics/quadruped.cpp.o"
  "CMakeFiles/common.dir/src/sim_utilities/spine_board.cpp.o"
  "CMakeFiles/common.dir/src/utilities/periodic_task.cpp.o"
  "CMakeFiles/common.dir/src/utilities/segfault_handler.cpp.o"
  "CMakeFiles/common.dir/src/utilities/utilities.cpp.o"
  "CMakeFiles/common.dir/src/utilities/utilities_print.cpp.o"
  "libcommon.pdb"
  "libcommon.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/common.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
