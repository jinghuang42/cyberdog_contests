file(REMOVE_RECURSE
  "CMakeFiles/lcm_type"
  "CMakeFiles/lcm_type-complete"
  "../../lcm_type/src/lcm_type-stamp/lcm_type-install"
  "../../lcm_type/src/lcm_type-stamp/lcm_type-mkdir"
  "../../lcm_type/src/lcm_type-stamp/lcm_type-download"
  "../../lcm_type/src/lcm_type-stamp/lcm_type-update"
  "../../lcm_type/src/lcm_type-stamp/lcm_type-patch"
  "../../lcm_type/src/lcm_type-stamp/lcm_type-configure"
  "../../lcm_type/src/lcm_type-stamp/lcm_type-build"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/lcm_type.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
