# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/common/third_party/ParamHandler/ParamHandler.cpp" "/work/build_farm/workspace/cyberdog/cyberdog_locomotion-master/onboard-build/common/third_party/ParamHandler/CMakeFiles/param_handler.dir/ParamHandler.cpp.o"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "BUILD_CYBERDOG2=1"
  "ONBOARD_BUILD=1"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "/usr/xcc/aarch64-openwrt-linux-gnu/aarch64-openwrt-linux-gnu/usr/include/eigen3"
  "../common/include"
  "../common/third_party/ParamHandler"
  "../common/third_party/rapidjson"
  "../common/third_party/cpptoml/include"
  "."
  "/usr/xcc/aarch64-openwrt-linux-gnu/aarch64-openwrt-linux-gnu/usr/local/include"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
